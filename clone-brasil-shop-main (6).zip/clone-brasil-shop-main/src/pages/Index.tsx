import { useNavigate } from "react-router-dom";
import { ProductCarousel } from "@/components/ProductCarousel";
import { ProductInfo } from "@/components/ProductInfo";
import { ReviewCard } from "@/components/ReviewCard";
import { StoreReviews } from "@/components/StoreReviews";
import { ProductDetails } from "@/components/ProductDetails";
import { ProductDescription } from "@/components/ProductDescription";
import { ProductMediaGallery } from "@/components/ProductMediaGallery";
import { ProductFeatures } from "@/components/ProductFeatures";
import { Button } from "@/components/ui/button";
import { SupportChat } from "@/components/SupportChat";
import { X, Share2, ShoppingCart, Heart, Home, MessageCircle } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const Index = () => {
  const navigate = useNavigate();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  
  const productImages = [
    "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&h=800&fit=crop",
    "https://images.unsplash.com/photo-1545127398-14699f92334b?w=800&h=800&fit=crop",
    "https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800&h=800&fit=crop",
    "https://images.unsplash.com/photo-1589492477829-5e65395b66cc?w=800&h=800&fit=crop",
    "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=800&h=800&fit=crop",
    "https://images.unsplash.com/photo-1572536147248-ac99a00cfac0?w=800&h=800&fit=crop",
  ];

  const handleBuyNow = () => {
    navigate("/checkout");
  };

  const reviews = [
    {
      username: "@lucasouzah__",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=faces",
      rating: 5,
      comment:
        "JBL é incomparável! Qualidade superior à Boombox 2. Eu já tive a 2 e posso dizer que a 3 tem som ainda melhor! A bateria está excelente, pra mim tá mais que perfeita.",
      image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=200&h=200&fit=crop",
    },
    {
      username: "@fernanda_oliveira_10",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=faces",
      rating: 5,
      comment: "Produto muito bom, valeu muito a pena, qualidade excelente.",
      image: "https://images.unsplash.com/photo-1545127398-14699f92334b?w=200&h=200&fit=crop",
    },
    {
      username: "@carlos_19_santos",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=faces",
      rating: 5,
      comment:
        "Estou muito satisfeito com minha compra! Além de linda, tem ótimo som e qualidade excelente. Em breve comprarei outra.",
      image: "https://images.unsplash.com/photo-1484704849700-f032a568e944?w=200&h=200&fit=crop",
    },
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <div className="sticky top-0 z-50 flex items-center justify-between bg-card p-4 shadow-sm">
        <Button variant="ghost" size="icon">
          <X className="h-6 w-6" />
        </Button>
        <div className="flex gap-2">
          <Button variant="ghost" size="icon">
            <Share2 className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon">
            <ShoppingCart className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Product Carousel */}
      <ProductCarousel images={productImages} />

      {/* Product Info */}
      <ProductInfo
        title="SABALA Dr-909 - Caixa de som Bluetooth portátil"
        price={47.0}
        originalPrice={127.88}
        discount={96}
        rating={4.8}
        reviews={2398}
        sold="5k+"
      />

      {/* Store Reviews */}
      <div className="mt-4">
        <StoreReviews />
      </div>

      {/* Product Details */}
      <div className="mt-4">
        <ProductDetails />
      </div>

      {/* Product Description */}
      <div className="mt-4">
        <ProductDescription />
      </div>

      {/* Reviews Section */}
      <div className="mt-4 bg-card p-4">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Avaliações dos Clientes (472)</h2>
          <Button variant="link" className="text-sm text-accent">
            Ver mais &gt;
          </Button>
        </div>
        <div className="mb-4 flex items-center gap-2">
          <span className="text-3xl font-bold">4.9</span>
          <span className="text-muted-foreground">/ 5</span>
          <div className="flex">
            {Array.from({ length: 5 }).map((_, i) => (
              <span key={i} className="text-yellow-400">★</span>
            ))}
          </div>
        </div>
        <div className="space-y-4">
          {reviews.map((review, index) => (
            <ReviewCard 
              key={index} 
              {...review} 
              onImageClick={() => review.image && setSelectedImage(review.image)}
            />
          ))}
        </div>
      </div>

      {/* Image Dialog */}
      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-3xl p-0">
          {selectedImage && (
            <img 
              src={selectedImage} 
              alt="Review" 
              className="w-full h-auto rounded-lg"
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Product Media Gallery */}
      <div className="mt-4">
        <ProductMediaGallery />
      </div>

      {/* Product Features */}
      <div className="mt-4">
        <ProductFeatures />
      </div>

      {/* Footer Accordion */}
      <div className="mt-4 bg-card p-4 mb-20">
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="legal">
            <AccordionTrigger className="text-left font-semibold">
              Aviso Legal
            </AccordionTrigger>
            <AccordionContent className="text-sm text-muted-foreground">
              <p>• A duração da bateria depende do uso que se dê ao produto.</p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="shopping">
            <AccordionTrigger className="text-left font-semibold">
              Comece a comprar
            </AccordionTrigger>
            <AccordionContent className="text-sm text-muted-foreground">
              <p>Explore nossa ampla seleção de produtos de áudio premium e encontre o que você precisa.</p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="money">
            <AccordionTrigger className="text-left font-semibold">
              Ganhe dinheiro conosco
            </AccordionTrigger>
            <AccordionContent className="text-sm text-muted-foreground">
              <p>Torne-se um afiliado e ganhe comissões em cada venda realizada através do seu link exclusivo.</p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="company">
            <AccordionTrigger className="text-left font-semibold">
              Informações da empresa
            </AccordionTrigger>
            <AccordionContent className="text-sm text-muted-foreground">
              <p>SABALA é uma marca líder em tecnologia de áudio, dedicada a oferecer produtos de alta qualidade com design moderno e tecnologia avançada.</p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="support">
            <AccordionTrigger className="text-left font-semibold">
              Suporte ao cliente
            </AccordionTrigger>
            <AccordionContent className="text-sm text-muted-foreground">
              <p>Nossa equipe de suporte está disponível 24/7 para ajudar com qualquer dúvida ou problema que você possa ter.</p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="policy">
            <AccordionTrigger className="text-left font-semibold">
              Política e legal
            </AccordionTrigger>
            <AccordionContent className="text-sm text-muted-foreground">
              <p>Todos os direitos reservados © 2024 SABALA. Política de Privacidade | Termos de Uso | Política de Reembolso</p>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 flex items-center gap-2 border-t border-border bg-card p-4">
        <Button variant="ghost" size="icon" className="flex-col gap-1">
          <Home className="h-5 w-5" />
          <span className="text-xs">Loja</span>
        </Button>
        <Button variant="ghost" size="icon" className="flex-col gap-1">
          <MessageCircle className="h-5 w-5" />
          <span className="text-xs">Chat</span>
        </Button>
        <Button variant="outline" className="flex-1" size="lg">
          <Heart className="mr-2 h-5 w-5" />
          Adicionar ao carrinho
        </Button>
        <Button 
          className="flex-1 bg-accent hover:bg-accent/90" 
          size="lg"
          onClick={handleBuyNow}
        >
          Comprar Agora
        </Button>
      </div>

      {/* Support Chat */}
      <SupportChat />
    </div>
  );
};

export default Index;
