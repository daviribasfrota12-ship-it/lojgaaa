import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Check, ShieldCheck, Minus, Plus } from "lucide-react";

const Checkout = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [quantity, setQuantity] = useState(1);
  const [shippingMethod, setShippingMethod] = useState("express");
  
  const [identificationData, setIdentificationData] = useState({
    email: "",
    phone: "",
    fullName: "",
    cpfCnpj: "",
  });

  const [deliveryData, setDeliveryData] = useState({
    cep: "",
    address: "",
    number: "",
    complement: "",
    neighborhood: "",
    city: "",
    state: "",
    country: "Brasil",
  });

  const unitPrice = 49.99;
  const subtotal = unitPrice * quantity;
  const shipping = 0; // Frete grátis
  const total = subtotal;

  const handleNextStep = () => {
    if (currentStep === 3) {
      // Redirecionar para o gateway de pagamento EvoPay
      window.location.href = "https://app.evopay.cash/checkout/cmi0hq8ny00tg11dlqz1gst1g";
    } else {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePreviousStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    } else {
      navigate("/");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header with TikTok Shop Logo */}
      <div className="border-b border-border bg-card p-6 shadow-sm">
        <div className="mx-auto flex max-w-6xl items-center gap-3">
          <svg className="h-12 w-12" viewBox="0 0 48 48" fill="none">
            <path
              d="M34.5 10.5c-1.5-3-4.5-5-8-5-5 0-9 4-9 9v14c0 3.3-2.7 6-6 6s-6-2.7-6-6 2.7-6 6-6c.8 0 1.5.1 2.2.4v-8.5c-.7-.1-1.4-.2-2.2-.2-8.3 0-15 6.7-15 15s6.7 15 15 15 15-6.7 15-15V19.5c2.9 2 6.4 3.2 10.2 3.2V13.7c-1.5 0-3-.5-4.2-1.3-1.5-1-2.7-2.4-3-3.9z"
              fill="#00F2EA"
            />
            <path
              d="M38.5 13.5c-1.5-3-4.5-5-8-5-5 0-9 4-9 9v14c0 3.3-2.7 6-6 6s-6-2.7-6-6 2.7-6 6-6c.8 0 1.5.1 2.2.4v-8.5c-.7-.1-1.4-.2-2.2-.2-8.3 0-15 6.7-15 15s6.7 15 15 15 15-6.7 15-15V22.5c2.9 2 6.4 3.2 10.2 3.2V16.7c-1.5 0-3-.5-4.2-1.3-1.5-1-2.7-2.4-3-3.9z"
              fill="#FF0050"
            />
            <path
              d="M42 16c-1.5-3-4.5-5-8-5-5 0-9 4-9 9v14c0 3.3-2.7 6-6 6s-6-2.7-6-6 2.7-6 6-6c.8 0 1.5.1 2.2.4v-8.5c-.7-.1-1.4-.2-2.2-.2-8.3 0-15 6.7-15 15s6.7 15 15 15 15-6.7 15-15V25c2.9 2 6.4 3.2 10.2 3.2V19.2c-1.5 0-3-.5-4.2-1.3-1.5-1-2.7-2.4-3-3.9z"
              fill="#000000"
            />
          </svg>
          <h1 className="text-4xl font-bold">TikTok Shop</h1>
        </div>
      </div>

      <div className="mx-auto max-w-6xl p-6">
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Steps Indicator */}
            <div className="mb-8 flex items-center justify-center gap-4">
              <div className="flex items-center gap-2">
                <div className={`flex h-10 w-10 items-center justify-center rounded-full ${currentStep >= 1 ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground'}`}>
                  {currentStep > 1 ? <Check className="h-5 w-5" /> : "1"}
                </div>
                <span className={`text-sm font-medium ${currentStep >= 1 ? 'text-foreground' : 'text-muted-foreground'}`}>
                  Identificação
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <div className={`flex h-10 w-10 items-center justify-center rounded-full ${currentStep >= 2 ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground'}`}>
                  {currentStep > 2 ? <Check className="h-5 w-5" /> : "2"}
                </div>
                <span className={`text-sm font-medium ${currentStep >= 2 ? 'text-foreground' : 'text-muted-foreground'}`}>
                  Entrega
                </span>
              </div>
              
              <div className="flex items-center gap-2">
                <div className={`flex h-10 w-10 items-center justify-center rounded-full ${currentStep >= 3 ? 'bg-foreground text-background' : 'bg-muted text-muted-foreground'}`}>
                  3
                </div>
                <span className={`text-sm font-medium ${currentStep >= 3 ? 'text-foreground' : 'text-muted-foreground'}`}>
                  Pagamento
                </span>
              </div>
            </div>

            {/* Step 1: Identificação */}
            {currentStep === 1 && (
              <div className="rounded-lg bg-card p-6">
                <h2 className="mb-6 text-xl font-semibold">Identificação</h2>
                
                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="email">E-mail</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="email@email.com"
                        value={identificationData.email}
                        onChange={(e) => setIdentificationData({ ...identificationData, email: e.target.value })}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefone</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="(99) 99999-9999"
                        value={identificationData.phone}
                        onChange={(e) => setIdentificationData({ ...identificationData, phone: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Nome completo</Label>
                      <Input
                        id="fullName"
                        type="text"
                        placeholder="dasdasad dsad"
                        value={identificationData.fullName}
                        onChange={(e) => setIdentificationData({ ...identificationData, fullName: e.target.value })}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="cpfCnpj">CPF/CNPJ</Label>
                      <Input
                        id="cpfCnpj"
                        type="text"
                        placeholder="123.456.789-12"
                        value={identificationData.cpfCnpj}
                        onChange={(e) => setIdentificationData({ ...identificationData, cpfCnpj: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="mt-6 space-y-3 rounded-lg bg-muted/50 p-4">
                    <p className="font-medium">Usamos seus dados de forma 100% segura para garantir a sua satisfação:</p>
                    <div className="space-y-2">
                      <div className="flex items-start gap-2">
                        <Check className="mt-0.5 h-5 w-5 text-success" />
                        <span className="text-sm">Enviar o seu comprovante de compra e pagamento;</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="mt-0.5 h-5 w-5 text-success" />
                        <span className="text-sm">Ativar a sua garantia de devolução caso não fique satisfeito;</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Check className="mt-0.5 h-5 w-5 text-success" />
                        <span className="text-sm">Acompanhar o andamento do seu pedido;</span>
                      </div>
                    </div>
                  </div>

                  <Button 
                    onClick={handleNextStep}
                    className="mt-6 w-full bg-foreground py-6 text-lg font-semibold hover:bg-foreground/90"
                  >
                    IR PARA A ENTREGA
                  </Button>
                </div>
              </div>
            )}

            {/* Step 2: Entrega */}
            {currentStep === 2 && (
              <div className="rounded-lg bg-card p-6">
                <h2 className="mb-2 text-xl font-semibold">Entrega</h2>
                <p className="mb-6 text-sm text-muted-foreground">
                  Outra pessoa irá receber o pedido? <a href="#" className="text-blue-600">Clique aqui</a>
                </p>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="cep">CEP</Label>
                    <Input
                      id="cep"
                      type="text"
                      placeholder="78040-123"
                      value={deliveryData.cep}
                      onChange={(e) => setDeliveryData({ ...deliveryData, cep: e.target.value })}
                    />
                  </div>

                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="address">Endereço</Label>
                      <Input
                        id="address"
                        type="text"
                        placeholder="ruaa mandioncaa"
                        value={deliveryData.address}
                        onChange={(e) => setDeliveryData({ ...deliveryData, address: e.target.value })}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="number">Número</Label>
                      <Input
                        id="number"
                        type="text"
                        placeholder="11111"
                        value={deliveryData.number}
                        onChange={(e) => setDeliveryData({ ...deliveryData, number: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox id="noNumber" />
                    <label
                      htmlFor="noNumber"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      S/N
                    </label>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="complement">Complemento</Label>
                      <Input
                        id="complement"
                        type="text"
                        placeholder="casa"
                        value={deliveryData.complement}
                        onChange={(e) => setDeliveryData({ ...deliveryData, complement: e.target.value })}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="neighborhood">Bairro</Label>
                      <Input
                        id="neighborhood"
                        type="text"
                        placeholder="cascavel"
                        value={deliveryData.neighborhood}
                        onChange={(e) => setDeliveryData({ ...deliveryData, neighborhood: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2">
                      <Label htmlFor="city">Cidade</Label>
                      <Input
                        id="city"
                        type="text"
                        placeholder="cuiaba"
                        value={deliveryData.city}
                        onChange={(e) => setDeliveryData({ ...deliveryData, city: e.target.value })}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="state">Estado</Label>
                      <Select value={deliveryData.state} onValueChange={(value) => setDeliveryData({ ...deliveryData, state: value })}>
                        <SelectTrigger id="state">
                          <SelectValue placeholder="Mato Grosso" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="MT">Mato Grosso</SelectItem>
                          <SelectItem value="SP">São Paulo</SelectItem>
                          <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="country">País</Label>
                      <Select value={deliveryData.country} onValueChange={(value) => setDeliveryData({ ...deliveryData, country: value })}>
                        <SelectTrigger id="country">
                          <SelectValue placeholder="Brasil" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Brasil">Brasil</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="mt-6 space-y-3">
                    <div className="flex items-center justify-between rounded-lg border-2 border-green-500 bg-green-50 p-4">
                      <div className="flex items-center space-x-3">
                        <div>
                          <div className="font-medium">Frete grátis</div>
                          <p className="text-sm text-muted-foreground">5 a 10 dias úteis</p>
                        </div>
                      </div>
                      <span className="font-semibold text-green-600">Grátis</span>
                    </div>
                  </div>

                  <p className="text-xs text-muted-foreground">
                    A previsão de entrega pode variar de acordo com a região e facilidade de acesso ao seu endereço
                  </p>

                  <Button 
                    onClick={handleNextStep}
                    className="mt-6 w-full bg-foreground py-6 text-lg font-semibold hover:bg-foreground/90"
                  >
                    IR PARA O PAGAMENTO
                  </Button>
                </div>
              </div>
            )}

            {/* Step 3: Pagamento */}
            {currentStep === 3 && (
              <div className="rounded-lg bg-card p-6">
                <h2 className="mb-6 text-xl font-semibold">Pagamento</h2>
                
                <div className="space-y-4">
                  {/* Trust Badges Section */}
                  <div className="space-y-4 rounded-lg bg-muted/50 p-4">
                    {/* TikTok Shop */}
                    <div className="flex gap-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-foreground text-background">
                        <svg className="h-6 w-6" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                        </svg>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-1 text-yellow-500">
                          {[...Array(5)].map((_, i) => (
                            <span key={i}>★</span>
                          ))}
                        </div>
                        <h3 className="font-semibold">TikTok Shop</h3>
                        <p className="text-sm text-muted-foreground">
                          Você receberá o código de rastreio via e-mail em até 5 dias úteis para acompanhar a entrega da sua compra. Possuímos um sistema de entrega...
                        </p>
                        <button className="mt-1 text-sm text-blue-600">Ver mais</button>
                      </div>
                    </div>

                    {/* Garantia de Reembolso */}
                    <div className="flex gap-3 border-t border-border pt-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-500 text-white">
                        <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4"/>
                          <path d="M4 6v12c0 1.1.9 2 2 2h14v-4"/>
                          <path d="M18 12a2 2 0 0 0-2 2c0 1.1.9 2 2 2h4v-4h-4z"/>
                        </svg>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-1 text-yellow-500">
                          {[...Array(5)].map((_, i) => (
                            <span key={i}>★</span>
                          ))}
                        </div>
                        <h3 className="font-semibold">Garantia de Reembolso</h3>
                        <p className="text-sm text-muted-foreground">
                          Você tem até 15 dias para realizar trocas ou devoluções conforme a Políticas de Reembolso.
                        </p>
                        <button className="mt-1 text-sm text-blue-600">Ver mais</button>
                      </div>
                    </div>

                    {/* Reclame Aqui */}
                    <div className="flex gap-3 border-t border-border pt-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-600 text-white text-xl font-bold">
                        RA
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-1 text-yellow-500">
                          {[...Array(5)].map((_, i) => (
                            <span key={i}>★</span>
                          ))}
                        </div>
                        <h3 className="font-semibold">Reclame Aqui</h3>
                        <p className="text-sm text-muted-foreground">
                          15.623 Avaliações positivas para esta empresa.
                        </p>
                        <button className="mt-1 text-sm text-blue-600">Ver mais</button>
                      </div>
                    </div>

                    <div className="flex items-center justify-center gap-2 border-t border-border pt-4">
                      <ShieldCheck className="h-5 w-5" />
                      <span className="text-sm font-medium">Ambiente seguro</span>
                    </div>
                  </div>

                  {/* Pix Payment Section */}
                  <div className="rounded-lg border-2 border-border p-4">
                    <div className="flex items-center gap-3">
                      <svg className="h-12 w-12" viewBox="0 0 48 48" fill="none">
                        <rect x="4" y="4" width="40" height="40" rx="8" fill="#00C9A7"/>
                        <path d="M24 12v24M12 24h24" stroke="white" strokeWidth="3" strokeLinecap="round"/>
                      </svg>
                      <span className="text-lg font-semibold">Pix</span>
                    </div>
                  </div>

                  <div className="rounded-lg bg-muted/50 p-4 text-sm">
                    <p className="mb-3">Os pagamentos efetuados via Pix não podem ser parcelados. Seu produto será reservado e enviado somente após a confirmação do pagamento.</p>
                    
                    <div className="rounded-lg bg-card p-3">
                      <p className="font-semibold mb-2">Lembre-se:</p>
                      <ul className="space-y-1 text-sm">
                        <li>• Ao gerar o código atente para a data de expiração;</li>
                        <li>• O pagamento leva alguns minutos para ser processado;</li>
                      </ul>
                    </div>

                    <p className="mt-3 font-semibold text-primary">Valor no Pix: R${total.toFixed(2)}</p>
                  </div>

                  <Button 
                    onClick={handleNextStep}
                    className="mt-6 w-full bg-foreground py-6 text-lg font-semibold text-background hover:bg-foreground/90"
                  >
                    COMPRAR
                  </Button>
                </div>
              </div>
            )}

            {/* Voltar Button */}
            <Button
              variant="ghost"
              onClick={handlePreviousStep}
              className="mt-4 gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Voltar
            </Button>
          </div>

          {/* Cart Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-6 rounded-lg bg-card p-6 shadow-sm">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="font-semibold">Seu carrinho</h3>
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-foreground text-background text-xs font-bold">
                  {quantity}
                </div>
              </div>

              <div className="mb-4 flex gap-3 border-b border-border pb-4">
                <img 
                  src="https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=80&h=80&fit=crop" 
                  alt="SABALA DR909 Boombox" 
                  className="h-16 w-16 rounded object-cover"
                />
                <div className="flex-1">
                  <h4 className="text-sm font-semibold">SABALA DR909 Boombox</h4>
                  <p className="text-xs text-muted-foreground">Caixa de Som Bluetooth...</p>
                  <div className="mt-2 flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    >
                      <Minus className="h-3 w-3" />
                    </Button>
                    <span className="text-sm font-medium">{quantity}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => setQuantity(quantity + 1)}
                    >
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              </div>

              <div className="space-y-2 border-b border-border pb-4">
                <div className="flex justify-between text-sm">
                  <span>Subtotal</span>
                  <span>R$ {subtotal.toFixed(2)}</span>
                </div>
                {currentStep >= 2 && (
                  <div className="flex justify-between text-sm">
                    <span>Frete</span>
                    <span>Grátis</span>
                  </div>
                )}
              </div>

              <div className="mt-4 flex justify-between text-lg font-bold">
                <span>Total</span>
                <span>R$ {total.toFixed(2)}</span>
              </div>

              <div className="mt-4 flex items-center gap-2 rounded-lg bg-success/10 p-3">
                <ShieldCheck className="h-5 w-5 text-success" />
                <span className="text-sm font-medium text-success">Ambiente seguro</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 border-t border-border pt-6 text-center">
          <p className="text-sm text-muted-foreground">Formas de pagamento</p>
          <div className="mt-2 flex justify-center">
            <svg className="h-8 w-8" viewBox="0 0 48 48" fill="none">
              <rect x="4" y="4" width="40" height="40" rx="8" fill="#00C9A7"/>
              <path d="M24 12v24M12 24h24" stroke="white" strokeWidth="3" strokeLinecap="round"/>
            </svg>
          </div>
          <p className="mt-4 text-sm text-muted-foreground">© 2025 Tiktok Shop</p>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
