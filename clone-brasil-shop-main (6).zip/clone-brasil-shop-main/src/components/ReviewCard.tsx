import { Star } from "lucide-react";

interface ReviewCardProps {
  username: string;
  avatar: string;
  comment: string;
  image?: string;
  rating: number;
  onImageClick?: () => void;
}

export const ReviewCard = ({ username, avatar, comment, image, rating, onImageClick }: ReviewCardProps) => {
  const isImageUrl = avatar.startsWith('http');
  
  return (
    <div className="space-y-3 rounded-lg border border-border bg-card p-4">
      <div className="flex items-start gap-3">
        {isImageUrl ? (
          <img 
            src={avatar} 
            alt={username}
            className="h-10 w-10 rounded-full object-cover"
          />
        ) : (
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-sm font-semibold">
            {avatar}
          </div>
        )}
        <div className="flex-1">
          <p className="font-semibold text-foreground">{username}</p>
          <div className="mt-1 flex">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${
                  i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
      <p className="text-sm text-foreground">{comment}</p>
      {image && (
        <img
          src={image}
          alt="Review"
          className="h-24 w-24 rounded-lg object-cover cursor-pointer hover:opacity-80 transition-opacity"
          onClick={onImageClick}
        />
      )}
      <p className="text-xs text-muted-foreground">Item: Padrão</p>
    </div>
  );
};
