import { useState } from "react";
import { Dialog, DialogContent } from "./ui/dialog";
import { Button } from "./ui/button";
import { Play } from "lucide-react";
import productVideo from "@/assets/video-caixa.mp4";
import productFeatures from "@/assets/product-features.png";

export const ProductMediaGallery = () => {
  const [selectedMedia, setSelectedMedia] = useState<{ type: 'image' | 'video', src: string } | null>(null);

  return (
    <>
      <div className="bg-gradient-to-br from-primary/5 via-background to-secondary/5 p-6 rounded-xl border border-border/50 shadow-lg">
        <h2 className="mb-6 text-2xl font-bold text-center bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
          Vídeo do Produto
        </h2>
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-primary to-secondary rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-300"></div>
          <button
            onClick={() => setSelectedMedia({ type: 'video', src: productVideo })}
            className="relative w-full aspect-video overflow-hidden rounded-xl border-2 border-primary/20 bg-muted transition-all duration-300 hover:scale-[1.02] hover:border-primary/40 hover:shadow-2xl"
          >
            <video
              src={productVideo}
              className="h-full w-full object-cover"
              muted
              loop
              playsInline
            />
            <div className="absolute inset-0 flex items-center justify-center bg-black/40 group-hover:bg-black/30 transition-colors">
              <div className="rounded-full bg-primary p-4 shadow-lg group-hover:scale-110 transition-transform">
                <Play className="h-8 w-8 text-primary-foreground" fill="currentColor" />
              </div>
            </div>
            <div className="absolute bottom-4 left-4 right-4 text-white font-semibold text-lg drop-shadow-lg">
              Assista ao vídeo completo
            </div>
          </button>
        </div>
      </div>

      <Dialog open={!!selectedMedia} onOpenChange={() => setSelectedMedia(null)}>
        <DialogContent className="max-w-4xl p-0">
          {selectedMedia?.type === 'video' ? (
            <video
              controls
              autoPlay
              className="w-full rounded-lg"
              src={selectedMedia.src}
            >
              Seu navegador não suporta vídeos.
            </video>
          ) : (
            <img
              src={selectedMedia?.src}
              alt="Produto"
              className="w-full rounded-lg"
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};
