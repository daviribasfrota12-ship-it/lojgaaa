import foto1 from "@/assets/foto1.jpg";
import foto2 from "@/assets/foto2.jpg";
import foto3 from "@/assets/foto3.jpg";
import foto4 from "@/assets/foto4.jpg";
import foto5 from "@/assets/foto5.jpg";

export const ProductFeatures = () => {
  const features = [
    { src: foto1, alt: "200W alta potência - Alto-falante de Três Vias com 100W Woofers" },
    { src: foto5, alt: "Itens inclusos - Caixa de som, cabo USB, bolsa branca e manual" },
    { src: foto4, alt: "Versatilidade - Use em piscinas, casa, churrasco ou esportes" },
    { src: foto3, alt: "Bateria potente de 39000mAh - Até 36 horas de reprodução" },
    { src: foto2, alt: "Power Bank integrado - Mantenha-se ligado em qualquer lugar" },
  ];

  return (
    <div className="bg-card">
      <div className="space-y-0">
        {features.map((feature, index) => (
          <div key={index} className="w-full">
            <img
              src={feature.src}
              alt={feature.alt}
              className="w-full h-auto object-cover"
            />
          </div>
        ))}
      </div>
    </div>
  );
};
