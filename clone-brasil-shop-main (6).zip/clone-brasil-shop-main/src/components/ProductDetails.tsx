export const ProductDetails = () => {
  const details = [
    { label: "Vida útil:", value: "24 meses" },
    { label: "Benefícios para a pele:", value: "Potência de saída, Conectividade Bluetooth, Resistência à água" },
    { label: "Tipo de embalagem:", value: "Item único" },
  ];

  return (
    <div className="bg-card p-4">
      <h2 className="text-lg font-semibold mb-4">Sobre este produto</h2>
      
      <h3 className="font-semibold mb-3">Detalhes</h3>
      
      <div className="space-y-3">
        {details.map((detail, index) => (
          <div key={index} className="grid grid-cols-[140px_1fr] gap-4">
            <span className="text-muted-foreground">{detail.label}</span>
            <span className="text-foreground">{detail.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
