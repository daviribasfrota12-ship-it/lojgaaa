import { Camera, Star } from "lucide-react";
import { Button } from "./ui/button";
import sabalaLogo from "@/assets/sabala-logo.png";

export const StoreReviews = () => {
  return (
    <div className="bg-card p-4">
      <h2 className="text-lg font-semibold mb-4">Avaliações da loja (7,8 mil)</h2>
      
      <div className="flex items-center justify-between mb-4 p-3 bg-muted/50 rounded-lg">
        <div className="flex items-center gap-2">
          <Camera className="h-5 w-5 text-primary" />
          <span className="text-sm">Inclui imagens ou vídeos (711)</span>
        </div>
        <div className="flex items-center gap-1">
          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
          <span className="font-semibold">5</span>
          <span className="text-sm text-muted-foreground">(6,2 mil)</span>
        </div>
      </div>

      <div className="flex items-center justify-between p-3 border border-border rounded-lg">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full overflow-hidden bg-white">
            <img src={sabalaLogo} alt="SABALA" className="h-full w-full object-contain" />
          </div>
          <div>
            <p className="font-semibold">SABALA Brasil</p>
            <p className="text-sm text-muted-foreground">46.6K vendido(s)</p>
          </div>
        </div>
        <Button variant="outline" size="sm">
          Visitar
        </Button>
      </div>
    </div>
  );
};
