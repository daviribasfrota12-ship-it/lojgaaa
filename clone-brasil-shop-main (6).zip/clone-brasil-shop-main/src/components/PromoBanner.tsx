import { useEffect, useState } from "react";

export const PromoBanner = () => {
  const [timeLeft, setTimeLeft] = useState(60 * 60); // 60 minutes in seconds

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  return (
    <div className="sticky top-0 z-50 bg-gradient-to-r from-orange-500 to-orange-600 text-white py-2 px-4 flex items-center justify-between text-sm font-semibold">
      <span>⚡ Oferta Relâmpago</span>
      <span>Termina em {formatTime(timeLeft)}</span>
    </div>
  );
};
