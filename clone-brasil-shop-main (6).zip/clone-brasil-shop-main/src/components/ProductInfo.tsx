import { Star, Truck } from "lucide-react";
import { Badge } from "./ui/badge";
import { useEffect, useState } from "react";

interface ProductInfoProps {
  title: string;
  price: number;
  originalPrice: number;
  discount: number;
  rating: number;
  reviews: number;
  sold: string;
}

export const ProductInfo = ({
  title,
  price,
  originalPrice,
  discount,
  rating,
  reviews,
  sold,
}: ProductInfoProps) => {
  const [timeLeft, setTimeLeft] = useState(60 * 60);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  return (
    <div className="space-y-4 bg-card p-4">
      {/* Promo Banner with Timer */}
      <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white p-3 rounded-lg flex items-center justify-between">
        <span className="font-semibold">⚡ Oferta Relâmpago</span>
        <span className="font-bold">Termina em {formatTime(timeLeft)}</span>
      </div>

      <div className="flex items-center gap-2">
        <Badge variant="destructive" className="text-sm font-bold">
          -{discount}%
        </Badge>
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-bold text-foreground">
            R$ {price.toFixed(2)}
          </span>
          <span className="text-sm text-muted-foreground line-through">
            R$ {originalPrice.toFixed(2)}
          </span>
        </div>
      </div>

      <h1 className="text-xl font-semibold text-foreground">{title}</h1>

      <div className="flex items-center gap-4 text-sm">
        <div className="flex items-center gap-1">
          <span className="font-semibold">{rating}</span>
          <div className="flex">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${
                  i < Math.floor(rating)
                    ? "fill-yellow-400 text-yellow-400"
                    : "text-gray-300"
                }`}
              />
            ))}
          </div>
        </div>
        <span className="text-muted-foreground">
          {reviews.toLocaleString()} avaliações
        </span>
        <span className="text-muted-foreground">{sold} vendidos</span>
      </div>

      <div className="flex items-center gap-2 rounded-lg border border-border bg-success/10 p-3">
        <Truck className="h-5 w-5 text-success" />
        <div>
          <p className="font-semibold text-success">Frete Grátis</p>
          <p className="text-sm text-muted-foreground">
            Receba até {new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}
          </p>
        </div>
      </div>

      <div className="flex items-center justify-center py-2">
        <img
          src="https://freepnglogo.com/images/all_img/1714299055tiktok-shop-logo-png.png"
          alt="TikTok Shop"
          className="h-8"
        />
      </div>
    </div>
  );
};
