export const ProductDescription = () => {
  return (
    <div className="bg-card p-4">
      <h2 className="text-xl font-bold mb-4">
        A SABALA Dr-909 é para todas as festas!
      </h2>

      <div className="space-y-4 text-foreground">
        <div>
          <h3 className="font-semibold text-lg mb-2">EXPERIÊNCIA IMERSIVA</h3>
          <p>
            Aproveite o som incrível SABALA Original Pro com graves profundos, garantindo uma experiência sonora imersiva e envolvente em qualquer lugar.
          </p>
        </div>

        <div>
          <h3 className="font-semibold text-lg mb-2">ESPETÁCULO DE LUZES</h3>
          <p>
            Transforme qualquer ambiente em uma pista de dança com o show de luzes dinâmico, que acompanha o ritmo da sua música, adicionando mais cores na festa.
          </p>
        </div>

        <div>
          <h3 className="font-semibold text-lg mb-2">ATÉ 6 HORAS DE BATERIA</h3>
          <p>
            Com até 6 horas de tempo de reprodução, a SABALA Dr-909 permite que você mantenha a festa em movimento, sem se preocupar com tomadas ou cabos.
          </p>
        </div>

        <div>
          <h3 className="font-semibold text-lg mb-2">À PROVA DE ÁGUA</h3>
          <p>
            Dance sem preocupações na praia ou à beira da piscina, pois a SABALA Dr-909 é à prova de água IPX6, garantindo durabilidade mesmo em ambientes úmidos.
          </p>
        </div>

        <div className="mt-6">
          <h3 className="font-semibold text-lg mb-3">QUAL O CONTEÚDO DA CAIXA?</h3>
          <ul className="space-y-2 list-disc list-inside">
            <li>1 SABALA Dr-909</li>
            <li>1 Cabo de energia AC (o plugue AC e a quantidade variam conforme a região)</li>
            <li>1 Guia de início rápido</li>
            <li>1 Ficha de segurança</li>
          </ul>
        </div>

        <p className="text-sm text-muted-foreground mt-6 italic">
          A SABALA destaca-se com áudio de alta qualidade, tecnologia avançada e design moderno, proporcionando momentos únicos na vida das pessoas.
        </p>
      </div>
    </div>
  );
};
